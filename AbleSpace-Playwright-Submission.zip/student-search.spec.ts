
import { test, expect } from '@playwright/test';
import 'dotenv/config';

test('AbleSpace accepts registered email and advances to password', async ({ page }) => {
  const email = process.env.ABLESPACE_EMAIL;

  expect(email, 'Set ABLESPACE_EMAIL in .env').toBeTruthy();
  expect(email).not.toBe('your_registered_email');
  expect(email).toContain('@');

  await page.goto('/');

  await expect(
    page.getByRole('heading', { name: 'Log in to your account' })
  ).toBeVisible();

  await page.getByLabel('Email').fill(email!);
  await page.getByRole('button', { name: /^Continue$/i }).click();

  const passwordField = page.getByRole('textbox', { name: 'Password' });
  await expect(passwordField).toBeVisible({ timeout: 10000 });

  const password = process.env.ABLESPACE_PASSWORD;
  expect(password, 'Set ABLESPACE_PASSWORD in .env').toBeTruthy();

 await passwordField.fill(password!);

// Submit the password
await page.getByRole('button', { name: /^Continue$/i }).click();

// Wait for the login request and page transition
await page.waitForLoadState('domcontentloaded');

console.log('URL after login:', page.url());

// Capture the result for inspection
await page.screenshot({
  path: 'login-result.png',
  fullPage: true
});