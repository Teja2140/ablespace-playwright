\# AbleSpace QA Automation – Playwright



\## Overview

This project contains a basic Playwright automation test for the AbleSpace staging login flow, written in TypeScript.



\## Tools

\- Playwright Test

\- TypeScript

\- Node.js

\- dotenv for environment variables



\## Setup

1\. Install Node.js.

2\. Clone or download this project.

3\. Install dependencies:



&#x20;  ```bash

&#x20;  npm install

&#x20;  npx playwright install chromium

&#x20;  ```



4\. Create a `.env` file in the project root:



&#x20;  ```dotenv

&#x20;  ABLESPACE\_EMAIL=tejilalguguloth546@gmail.com

&#x20;  ABLESPACE\_PASSWORD=Guguloth@546

&#x20;  ```



&#x20;  Replace the placeholders with your own registered credentials. Never commit `.env`.



\## Run Tests



```bash

npx playwright test --config=playwright.config.ts

```



\## Current Test Coverage

\- Verifies the AbleSpace login page heading.

\- Enters the registered email and verifies that the password field appears.



\## Limitations

The complete login flow and Caseload student-search flow have not yet been verified by automation.



